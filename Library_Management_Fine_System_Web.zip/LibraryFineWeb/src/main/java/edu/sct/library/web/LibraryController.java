package edu.sct.library.web;
import edu.sct.library.exception.LibraryException;
import edu.sct.library.service.LibraryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LibraryController {
  private final LibraryService service;
  public LibraryController(LibraryService service){this.service=service;}
  @GetMapping("/")
  public String home(@RequestParam(required=false,defaultValue="") String q,Model model){
    model.addAttribute("items",service.searchItems(q)); model.addAttribute("q",q);
    model.addAttribute("totalItems",service.countItems()); model.addAttribute("issuedItems",service.countIssued());
    return "index";
  }
  @PostMapping("/items")
  public String add(@RequestParam String type,@RequestParam String title,@RequestParam String author,RedirectAttributes r){
    try{int id=service.addItem(type,title,author);r.addFlashAttribute("success","Item added successfully. New item ID: "+id);}
    catch(LibraryException e){r.addFlashAttribute("error",e.getMessage());} return "redirect:/";
  }
  @PostMapping("/issue")
  public String issue(@RequestParam int itemId,@RequestParam String memberId,RedirectAttributes r){
    try{service.issueItem(itemId,memberId);r.addFlashAttribute("success","Item issued. Due date is 14 days from today.");}
    catch(LibraryException e){r.addFlashAttribute("error",e.getMessage());} return "redirect:/";
  }
  @PostMapping("/return")
  public String returnItem(@RequestParam int itemId,RedirectAttributes r){
    try{double fine=service.returnItem(itemId);r.addFlashAttribute("success",String.format("Item returned. Late fine: ₹%.2f",fine));}
    catch(LibraryException e){r.addFlashAttribute("error",e.getMessage());} return "redirect:/";
  }
}
