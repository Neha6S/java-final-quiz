package edu.sct.library.model;
public class Book extends LibraryItem {
  public Book() {}
  public Book(int id,String title,String author,boolean issued){super(id,title,author,issued);}
  public String getItemType(){return "BOOK";}
  public double calculateLateFine(int days){return Math.max(0,days)*2.0;}
}
