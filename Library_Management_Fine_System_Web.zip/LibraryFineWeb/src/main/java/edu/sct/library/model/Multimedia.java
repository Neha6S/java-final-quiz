package edu.sct.library.model;
public class Multimedia extends LibraryItem {
  public Multimedia() {}
  public Multimedia(int id,String title,String author,boolean issued){super(id,title,author,issued);}
  public String getItemType(){return "MULTIMEDIA";}
  public double calculateLateFine(int days){return Math.max(0,days)*10.0;}
}
