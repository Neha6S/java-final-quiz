package edu.sct.library.model;
public abstract class LibraryItem implements FinePolicy {
  private int id; private String title; private String author; private boolean issued;
  protected LibraryItem() {}
  protected LibraryItem(int id, String title, String author, boolean issued) {
    this.id=id; this.title=title; this.author=author; this.issued=issued;
  }
  public abstract String getItemType();
  public int getId(){return id;} public void setId(int v){id=v;}
  public String getTitle(){return title;} public void setTitle(String v){title=v;}
  public String getAuthor(){return author;} public void setAuthor(String v){author=v;}
  public boolean isIssued(){return issued;} public void setIssued(boolean v){issued=v;}
}
