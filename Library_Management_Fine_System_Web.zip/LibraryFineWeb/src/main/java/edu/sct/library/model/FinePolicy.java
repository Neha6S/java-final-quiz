package edu.sct.library.model;
public interface FinePolicy { double calculateLateFine(int daysOverdue); }
