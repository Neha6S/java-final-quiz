package edu.sct.library.service;

import edu.sct.library.exception.LibraryException;
import edu.sct.library.model.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;

@Service
public class LibraryService {
  private final JdbcTemplate jdbc;
  public LibraryService(JdbcTemplate jdbc){this.jdbc=jdbc;}

  public List<LibraryItem> searchItems(String q) {
    String term="%"+(q==null?"":q.trim().toLowerCase(Locale.ROOT))+"%";
    return jdbc.query("SELECT id,title,author,type,issued FROM library_items WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ? ORDER BY id DESC",
      (rs,row)->mapItem(rs.getInt("id"),rs.getString("title"),rs.getString("author"),rs.getString("type"),rs.getBoolean("issued")),term,term);
  }
  public int countItems(){Integer n=jdbc.queryForObject("SELECT COUNT(*) FROM library_items",Integer.class);return n==null?0:n;}
  public int countIssued(){Integer n=jdbc.queryForObject("SELECT COUNT(*) FROM library_items WHERE issued=TRUE",Integer.class);return n==null?0:n;}

  public int addItem(String type,String title,String author) {
    if(title==null||title.isBlank()||author==null||author.isBlank()) throw new LibraryException("Please enter both a title and an author.");
    LibraryItem item=createItem(type,0,title.trim(),author.trim(),false);
    jdbc.update("INSERT INTO library_items(title,author,type,issued) VALUES(?,?,?,FALSE)",item.getTitle(),item.getAuthor(),item.getItemType());
    return jdbc.queryForObject("SELECT MAX(id) FROM library_items",Integer.class);
  }

  @Transactional
  public void issueItem(int id,String memberId) {
    if(memberId==null||memberId.isBlank()) throw new LibraryException("Member ID is required.");
    List<LibraryItem> found=jdbc.query("SELECT id,title,author,type,issued FROM library_items WHERE id=?",
      (rs,row)->mapItem(rs.getInt("id"),rs.getString("title"),rs.getString("author"),rs.getString("type"),rs.getBoolean("issued")),id);
    if(found.isEmpty()) throw new LibraryException("No item exists with that ID.");
    if(found.get(0).isIssued()) throw new LibraryException("This item is already issued.");
    LocalDate today=LocalDate.now();
    jdbc.update("UPDATE library_items SET issued=TRUE WHERE id=?",id);
    jdbc.update("INSERT INTO loans(item_id,member_id,issue_date,due_date,returned,fine) VALUES(?,?,?,?,FALSE,0)",id,memberId.trim(),today,today.plusDays(14));
  }

  @Transactional
  public double returnItem(int id) {
    List<LoanRow> loans=jdbc.query("SELECT loan_id,due_date FROM loans WHERE item_id=? AND returned=FALSE ORDER BY loan_id DESC LIMIT 1",
      (rs,row)->new LoanRow(rs.getInt("loan_id"),rs.getDate("due_date").toLocalDate()),id);
    if(loans.isEmpty()) throw new LibraryException("No active loan was found for this item.");
    List<LibraryItem> items=jdbc.query("SELECT id,title,author,type,issued FROM library_items WHERE id=?",
      (rs,row)->mapItem(rs.getInt("id"),rs.getString("title"),rs.getString("author"),rs.getString("type"),rs.getBoolean("issued")),id);
    if(items.isEmpty()) throw new LibraryException("Item not found.");
    LocalDate today=LocalDate.now();
    int overdue=(int)Math.max(0,ChronoUnit.DAYS.between(loans.get(0).dueDate(),today));
    double fine=items.get(0).calculateLateFine(overdue);
    jdbc.update("UPDATE loans SET returned=TRUE,return_date=?,fine=? WHERE loan_id=?",today,fine,loans.get(0).loanId());
    jdbc.update("UPDATE library_items SET issued=FALSE WHERE id=?",id);
    return fine;
  }

  private LibraryItem mapItem(int id,String title,String author,String type,boolean issued){return createItem(type,id,title,author,issued);}
  private LibraryItem createItem(String type,int id,String title,String author,boolean issued) {
    if(type==null) throw new LibraryException("Please choose an item type.");
    return switch(type.toUpperCase(Locale.ROOT)) {
      case "BOOK" -> new Book(id,title,author,issued);
      case "JOURNAL" -> new Journal(id,title,author,issued);
      case "MULTIMEDIA" -> new Multimedia(id,title,author,issued);
      default -> throw new LibraryException("Choose Book, Journal or Multimedia.");
    };
  }
  private record LoanRow(int loanId,LocalDate dueDate){}
}
