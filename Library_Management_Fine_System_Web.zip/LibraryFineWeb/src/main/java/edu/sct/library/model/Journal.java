package edu.sct.library.model;
public class Journal extends LibraryItem {
  public Journal() {}
  public Journal(int id,String title,String author,boolean issued){super(id,title,author,issued);}
  public String getItemType(){return "JOURNAL";}
  public double calculateLateFine(int days){return Math.max(0,days)*5.0;}
}
