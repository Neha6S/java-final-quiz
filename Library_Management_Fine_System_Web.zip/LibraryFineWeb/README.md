# Library Management & Dynamic Fine System — Web Edition

Browser-based Java S3 project. It preserves the abstract item model and polymorphic fine policies while replacing Swing with a responsive website.

## Features
- Add/search Books, Journals and Multimedia
- Issue items to member IDs and return them
- Automatic fine calculation, with a 14-day loan period
- Book: ₹2/day; Journal: ₹5/day; Multimedia: ₹10/day
- Java abstract class, inheritance, overriding, interface, custom exception, JDBC, SQL and web form event handling

## Run locally
Requirements: JDK 17+ and Maven.
Run `mvn spring-boot:run`, then open `http://localhost:8080`.
H2 is used by default for a quick demo; its in-memory data resets when the app restarts.

## Deploy online with Render
1. Create a GitHub repository and upload the extracted project files.
2. In Render, create a Web Service connected to the repository.
3. Build Command: `mvn clean package -DskipTests`
4. Start Command: `java -jar target/library-fine-system.jar`
5. Deploy. Render provides a public HTTPS URL.

For a simple demo, default H2 is easiest, but stored records may reset when the service restarts or redeploys. For persistent records, connect a MySQL database and set environment variables:
- `DATABASE_URL=jdbc:mysql://HOST:3306/library_fine_system`
- `DB_DRIVER=com.mysql.cj.jdbc.Driver`
- `DB_USER=your_username`
- `DB_PASSWORD=your_password`

This is a student demonstration project and has no login/authentication. Avoid entering real private member data.
